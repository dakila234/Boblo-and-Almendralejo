# Event Crew

A group chat for student event organizers. In a normal chat, "who is doing what?" and "is everyone ready?"
get lost between messages. Event Crew puts two shared tools next to the chat, all on one screen:

1. **Task assignments** - add a task and assign it to a crew member (or leave it open), take an open task, mark your task done, reassign or remove it. Everyone sees the same list.
2. **Readiness acknowledgments** - anyone can start a readiness check ("Sound check at 3 PM"); every crew member then presses **I'm ready**. A panel shows who is ready, who is still waiting, and when everyone is ready.

Everything is in a pink theme, and every person's name has its own colour, so it is easy to see who is who. Built with Java Swing (JFrame) in Apache NetBeans. Plain TCP sockets, no external libraries.

## Concept Proposal

| | |
|---|---|
| **Audience** | Student event organizers (school program, foundation day, club event) |
| **Problem** | Tasks are shouted in a busy chat, nobody knows who owns what, and nobody can tell if the crew is ready when the event starts |
| **Feature 1** | Task assignments (add, assign, take, done, reassign, remove; shared task list) |
| **Feature 2** | Readiness acknowledgments (readiness check, I'm ready button, live ready / waiting panel) |
| **Sample screens** | _Add screenshots here: join screen, main screen with tasks, readiness panel, chat_ |
| **Instructor approval** | _Name / date:_ |

## How to run (NetBeans)

1. Unzip `EventCrew.zip`.
2. NetBeans: **File > Open Project...** and pick the `EventCrew` folder.
3. Right-click the project > **Run** (main class is `eventcrew.Launcher`).
4. In the launcher: **Start Server** on the host computer, then click **Start server** inside the Host Console. It must say "Running on port 5080".
5. Click **Open Client** for each user. On a second computer, enter the host's IP address (shown in the Host Console) and port `5080`.

If NetBeans cannot open it as a project: create a new *Java with Ant > Java Application*, then copy the
`src/eventcrew` files into it. Or run `run.bat` (Windows) / `run.sh` (Linux/Mac) with a JDK installed.

Requires JDK 11 or newer. Both computers must be on the same network and the server's firewall must allow the port.

## The screen

One window, no tabs, in pink:

- **Top band:** the event name, the number of tasks to do and done, and who is signed in.
- **Crew strip (readiness):** one chip per crew member (pink dot = ready, empty dot = waiting), the progress bar, and the **I'm ready** and **Start check** buttons.
- **Task checklist (left):** each task is a row with a round check circle, who has it, and only the buttons that apply to you (Take it, Done, Reassign, Remove). The add-task bar is at the bottom.
- **Crew chat (right):** messages with each person's name in their own colour.

The menu bar has Session > Leave and Help > Commands.

## Commands

| Command | What it does |
|---|---|
| `/list` | show who is online |
| `/msg <person> <text>` | private message |
| `/quit` | leave the chat |
| `/task Title \| person` | add a task (person is optional) |
| `/take <#>` | take an open task |
| `/done <#>` | mark a task done (assignee or the person who added it) |
| `/assign <#> <person>` | assign a task you added |
| `/deltask <#>` | remove a task you added |
| `/check <what>` | start a readiness check |
| `/ready` / `/notready` | answer the readiness check |

## Code overview

| File | Responsibility |
|---|---|
| `Protocol` | message format (`COMMAND\|field\|field`, fields URL-encoded), nickname validation |
| `Result` | outcome of a board action: a line to broadcast or an error |
| `ChatServer` | accept loop, online users, broadcast |
| `ClientHandler` | one thread per client; reads and handles that client's messages |
| `TaskBoard`, `Task` | server-side task list and its rules (synchronized) |
| `ReadinessBoard` | server-side readiness checks and who has acknowledged (synchronized) |
| `ClientConnection` | client socket, HELLO handshake, reader thread |
| `ConnectView/Frame` | join screen; connects in a `SwingWorker` so the window never freezes |
| `MainView`, `MainFrame` | main screen; moves incoming messages onto the Swing thread; menu bar |
| `TaskPanel` | feature 1: task checklist, add-task bar, Take it / Done / Reassign / Remove |
| `CrewStrip` | feature 2: crew chips (ready / waiting), progress bar, I'm ready and Start check |
| `ChatPanel` | chat log with coloured names and the input line |
| `ServerView/Frame`, `Launcher` | host console and start window |
| `Theme`, `Ui` | the pink theme, name colours, and custom-painted parts (pill buttons, rounded cards, check circles) |

Message path: user types -> `MainView` -> `ClientConnection.send` -> socket -> `ClientHandler.handle`
-> `TaskBoard` / `ReadinessBoard` (if a feature action) -> `ChatServer.broadcast` -> every `ClientHandler.send`
-> each client's reader thread -> `SwingUtilities.invokeLater` -> GUI update.

## Test evidence

See [TEST_EVIDENCE.md](TEST_EVIDENCE.md) for the automated test results (Part A) and the two-computer manual test sheet (Part B).

## Contribution log

| Partner | Work done | Evidence (commits, screenshots) |
|---|---|---|
| Partner 1 | | |
| Partner 2 | | |

## Credits and AI assistance

- Java SE / Swing (JDK standard library only).
- Code was generated with assistance from Claude (Anthropic) and then reviewed by the team.
  _Edit this line to describe what you changed or wrote yourselves._
