#!/bin/sh
# Compiles and starts the Study Circle launcher (needs a JDK).
cd "$(dirname "$0")"
mkdir -p out
javac -d out src/eventcrew/*.java && java -cp out eventcrew.Launcher
