@echo off
cd /d "%~dp0"
if not exist out mkdir out
javac -d out src\eventcrew\*.java && java -cp out eventcrew.Launcher
pause
