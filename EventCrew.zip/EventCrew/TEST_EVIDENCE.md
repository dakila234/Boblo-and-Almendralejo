# Test Evidence - Event Crew

## Part A: Automated test (already run)

`test/eventcrew/SmokeTest.java` starts a real `ChatServer` and connects three simulated clients
(Ana, Ben, Cy) over real sockets, then a fourth (Dee) later. To reproduce: in NetBeans open the file
and choose **Run File** (Shift+F6).

Run date: 2026-11-23, JDK 21, one computer (localhost). Result: **all 34 checks passed.**

| What was tested | Expected | Result |
|---|---|---|
| Join with a nickname already taken / invalid nickname | Rejected with message | PASS |
| Group message from Ana | Ana, Ben and Cy each receive it exactly once | PASS |
| Message containing the `\|` character | Arrives unchanged | PASS |
| Online list and private message | Correct users only | PASS |
| Add a task assigned to Ben | All clients see it | PASS |
| Add a task with nobody assigned | Shown as unassigned | PASS |
| Empty task / assign to someone offline | Refused with error | PASS |
| Take a task assigned to someone else | Refused with error | PASS |
| Take an open task | Assigned to the person who took it | PASS |
| Reassign by a non-creator / by the creator | Refused / allowed | PASS |
| Finish a task as the wrong person / as the assignee | Refused / marked done for everyone | PASS |
| Finish a task twice | Refused with error | PASS |
| Remove a task as a non-creator / as the creator | Refused / removed on every client | PASS |
| Readiness at the start | Everyone pending | PASS |
| Ben presses I'm ready, then changes his mind | READY, then PENDING, on every client | PASS |
| Everyone acknowledges | Everyone shown as ready | PASS |
| Start a readiness check | Everyone reset to pending and announced in chat | PASS |
| A member disconnects | Leave notice; readiness list without that member | PASS |
| Chat after a disconnect | Remaining users keep chatting | PASS |
| Late joiner | Receives existing tasks and appears as pending | PASS |
| Task checklist and Crew strip | Build and update without errors | PASS |

Raw output of the run:

```
PASS duplicate nickname rejected: The nickname 'ana' is already taken.
PASS invalid nickname rejected: Nickname may only contain letters, numbers, '_' and '-'.
PASS Ana got the group message exactly once
PASS Ben got the group message exactly once
PASS Cy got the group message exactly once
PASS the | character survives in text
PASS online list shows 3 users
PASS private message reaches Ben and Ana, not Cy
PASS Ana sees task 1 assigned to Ben
PASS Ben sees task 1 assigned to Ben
PASS Cy sees task 1 assigned to Ben
PASS a task can start with nobody assigned
PASS empty task refused
PASS assigning to someone offline refused
PASS cannot take a task assigned to someone else
PASS Cy takes the open task 2
PASS only the creator can reassign
PASS creator reassigns task 2 to Ben
PASS someone else cannot finish the task
PASS assignee finishes task 2
PASS finishing twice refused
PASS only the creator can remove a task
PASS creator removes task 1: REMOVED reaches clients
PASS readiness starts with everyone pending
PASS Ben acknowledges: shown READY to everyone
PASS Ben changes his mind: back to PENDING
PASS everyone ready
PASS a new check resets everyone to pending
PASS check announced in the chat
PASS leave notice and readiness list without Cy
PASS chat continues after a disconnect
PASS late joiner receives existing tasks and a pending status
PASS Task checklist and Crew strip build and update
ALL PASSED
```

## Part B: Manual test on two computers (fill in during your demo)

Setup used: Server on Computer ____ (IP ________, port 5080). Clients: ________ on Computer A,
________ and ________ on Computer B. Date tested: ________

| # | Test | Expected | Result (Pass/Fail) | Screenshot |
|---|---|---|---|---|
| 1 | Three clients connect across two computers | All appear as chips in the crew strip | | |
| 2 | Duplicate nickname on the join screen | Error message shown | | |
| 3 | Wrong port or server not running | "Could not reach the server" message, window does not freeze | | |
| 4 | Group chat | Each client sees each message once, with sender and time | | |
| 5 | Join and leave | Notice in chat and crew strip updates | | |
| 6 | Required commands (list them here) | Each works | | |
| 7 | Add tasks (assigned and open) | Appear on every screen | | |
| 8 | Take an open task, mark it done | Updates on every screen; done tasks get a pink check and are crossed out | | |
| 9 | Reassign and remove a task | Updates on every screen | | |
| 10 | Start a readiness check | Everyone shows "waiting" on every screen | | |
| 11 | Each member presses I'm ready | Ready count and bar update live; "Everyone is ready!" at the end | | |
| 12 | Close one client window | Others keep working | | |
| 13 | Stop the server while clients are open | Clients show a "lost connection" message and return to the join screen | | |

## Screenshots to attach

1. Join screen
2. Main screen with several tasks (some done)
3. Readiness panel mid-check and when everyone is ready
4. Crew chat with coloured names
5. Host Console log
