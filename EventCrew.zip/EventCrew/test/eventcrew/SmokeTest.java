package eventcrew;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Automated protocol test: starts a ChatServer on port 5999 and connects simulated clients.
 * Run it (Run File) to reproduce the results in TEST_EVIDENCE.md.
 */
public class SmokeTest {

    static class C implements ClientConnection.Listener {
        final String name;
        final ClientConnection conn = new ClientConnection();
        final BlockingQueue<String> got = new LinkedBlockingQueue<>();

        C(String n) { name = n; }

        public void onMessage(String[] p) { got.add(String.join("|", p)); }
        public void onClosed() { got.add("CLOSED"); }

        boolean has(String text, int ms) throws Exception {
            long end = System.currentTimeMillis() + ms;
            while (true) {
                for (String s : got) {
                    if (s.contains(text)) {
                        return true;
                    }
                }
                if (System.currentTimeMillis() >= end) {
                    return false;
                }
                Thread.sleep(50);
            }
        }

        int count(String prefix) {
            int n = 0;
            for (String s : got) {
                if (s.startsWith(prefix)) {
                    n++;
                }
            }
            return n;
        }
    }

    static int failures = 0;

    static void check(String what, boolean ok) {
        if (!ok) {
            failures++;
        }
        System.out.println((ok ? "PASS " : "FAIL ") + what);
    }

    public static void main(String[] a) throws Exception {
        ChatServer s = new ChatServer(new ChatServer.Listener() {
            public void onLog(String m) { }
            public void onUserCountChanged(int c) { }
        });
        s.start(5999);
        C[] c = {new C("Ana"), new C("Ben"), new C("Cy")};
        for (C x : c) {
            x.conn.connect("localhost", 5999, x.name);
            x.conn.startReading(x);
        }

        ClientConnection dup = new ClientConnection();
        try { dup.connect("localhost", 5999, "ana"); check("duplicate nickname rejected", false); }
        catch (Exception e) { check("duplicate nickname rejected: " + e.getMessage(), true); }
        ClientConnection bad = new ClientConnection();
        try { bad.connect("localhost", 5999, "a|b"); check("invalid nickname rejected", false); }
        catch (Exception e) { check("invalid nickname rejected: " + e.getMessage(), true); }

        Thread.sleep(300);
        c[0].conn.send(Protocol.build("MSG", "stage | lights?"));
        Thread.sleep(300);
        for (C x : c) {
            check(x.name + " got the group message exactly once", x.count("MSG|") == 1);
        }
        check("the | character survives in text", c[1].has("stage | lights?", 100));
        check("online list shows 3 users", c[2].has("USERS|Ana|Ben|Cy", 300));

        c[0].conn.send(Protocol.build("PM", "ben", "psst"));
        Thread.sleep(200);
        check("private message reaches Ben and Ana, not Cy",
                c[1].count("PM|") == 1 && c[0].count("PM|") == 1 && c[2].count("PM|") == 0);

        // feature 1: task assignments
        c[0].conn.send(Protocol.build("T_ADD", "Set up the stage", "ben"));
        Thread.sleep(250);
        for (C x : c) {
            check(x.name + " sees task 1 assigned to Ben", x.has("T_SET|1|Ana|Set up the stage|Ben|TODO", 300));
        }
        c[0].conn.send(Protocol.build("T_ADD", "Bring chairs", ""));
        Thread.sleep(200);
        check("a task can start with nobody assigned", c[2].has("T_SET|2|Ana|Bring chairs||TODO", 300));
        c[0].conn.send(Protocol.build("T_ADD", "   ", ""));
        check("empty task refused", c[0].has("ERR|A task needs a title", 300));
        c[0].conn.send(Protocol.build("T_ADD", "Ghost job", "Zed"));
        check("assigning to someone offline refused", c[0].has("ERR|'Zed' is not online", 300));

        c[2].conn.send(Protocol.build("T_TAKE", "1"));
        check("cannot take a task assigned to someone else", c[2].has("ERR|Task #1 is already assigned to Ben", 300));
        c[2].conn.send(Protocol.build("T_TAKE", "2"));
        Thread.sleep(200);
        check("Cy takes the open task 2", c[0].has("T_SET|2|Ana|Bring chairs|Cy|TODO", 300));
        c[1].conn.send(Protocol.build("T_ASSIGN", "2", "Ben"));
        check("only the creator can reassign", c[1].has("ERR|Only Ana can assign task #2", 300));
        c[0].conn.send(Protocol.build("T_ASSIGN", "2", "Ben"));
        Thread.sleep(200);
        check("creator reassigns task 2 to Ben", c[2].has("T_SET|2|Ana|Bring chairs|Ben|TODO", 300));
        c[2].conn.send(Protocol.build("T_DONE", "2"));
        check("someone else cannot finish the task", c[2].has("ERR|Only Ben can finish task #2", 300));
        c[1].conn.send(Protocol.build("T_DONE", "2"));
        Thread.sleep(200);
        check("assignee finishes task 2", c[0].has("T_SET|2|Ana|Bring chairs|Ben|DONE", 300));
        c[1].conn.send(Protocol.build("T_DONE", "2"));
        check("finishing twice refused", c[1].has("ERR|Task #2 is already done", 300));
        c[1].conn.send(Protocol.build("T_DEL", "1"));
        check("only the creator can remove a task", c[1].has("ERR|Only Ana can remove task #1", 300));
        c[0].conn.send(Protocol.build("T_DEL", "1"));
        Thread.sleep(200);
        check("creator removes task 1: REMOVED reaches clients", c[2].has("T_SET|1|Ana|Set up the stage|Ben|REMOVED", 300));

        // feature 2: readiness acknowledgments
        check("readiness starts with everyone pending", c[0].has("R_STATE|0|Standing readiness||Ana|PENDING|Ben|PENDING|Cy|PENDING", 300));
        c[1].conn.send(Protocol.build("R_ACK", "1"));
        Thread.sleep(250);
        check("Ben acknowledges: shown READY to everyone", c[2].has("|Ana|PENDING|Ben|READY|Cy|PENDING", 300));
        c[1].conn.send(Protocol.build("R_ACK", "0"));
        Thread.sleep(250);
        check("Ben changes his mind: back to PENDING", c[2].has("|Ana|PENDING|Ben|PENDING|Cy|PENDING", 300));
        c[0].conn.send(Protocol.build("R_ACK", "1"));
        c[1].conn.send(Protocol.build("R_ACK", "1"));
        c[2].conn.send(Protocol.build("R_ACK", "1"));
        Thread.sleep(300);
        check("everyone ready", c[0].has("|Ana|READY|Ben|READY|Cy|READY", 300));
        c[0].conn.send(Protocol.build("R_CHECK", "Sound check at 3 PM"));
        Thread.sleep(300);
        check("a new check resets everyone to pending",
                c[1].has("R_STATE|1|Sound check at 3 PM|Ana|Ana|PENDING|Ben|PENDING|Cy|PENDING", 300));
        check("check announced in the chat", c[2].has("started readiness check #1: Sound check at 3 PM", 300));
        c[2].conn.send(Protocol.build("R_ACK", "1"));
        Thread.sleep(250);

        c[2].conn.disconnect();
        Thread.sleep(400);
        check("leave notice and readiness list without Cy",
                c[0].has("left the crew", 300) && c[0].has("R_STATE|1|Sound check at 3 PM|Ana|Ana|PENDING|Ben|PENDING", 300));
        c[0].conn.send(Protocol.build("MSG", "still here"));
        check("chat continues after a disconnect", c[1].has("still here", 300));

        C late = new C("Dee");
        late.conn.connect("localhost", 5999, "Dee");
        late.conn.startReading(late);
        check("late joiner receives existing tasks and a pending status",
                late.has("T_SET|2|Ana|Bring chairs|Ben|DONE", 400) && late.has("Dee|PENDING", 400));

        // GUI panels (lightweight components work without a screen)
        javax.swing.SwingUtilities.invokeAndWait(() -> {
            TaskPanel tp = new TaskPanel("Ben", l -> { });
            CrewStrip rp = new CrewStrip("Ben", l -> { });
            String[] task = Protocol.parse(Protocol.build("T_SET", "1", "Ana", "Stage", "Ben", "TODO"));
            tp.setOnline(java.util.Arrays.asList("Ana", "Ben"));
            tp.setTasks(java.util.Collections.singletonList(task));
            rp.setReadiness(Protocol.parse(Protocol.build("R_STATE", "1", "Sound check", "Ana",
                    "Ana", "READY", "Ben", "PENDING")));
            tp.setTasks(new java.util.ArrayList<>());
        });
        check("Task checklist and Crew strip build and update", true);

        s.stop();
        System.out.println(failures == 0 ? "ALL PASSED" : failures + " FAILED");
        System.exit(failures == 0 ? 0 : 1);
    }
}
