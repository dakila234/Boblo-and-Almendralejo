package eventcrew;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Consumer;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;

/**
 * Feature 1: task assignments, shown as a checklist. Each task is a row with a round check
 * circle, the title, who has it, and only the buttons that make sense for you
 * (Take it, Done, Reassign, Remove). The server owns the data; this panel shows T_SET messages.
 */
class TaskPanel extends JPanel {

    private static final String NOBODY = "(nobody yet)";

    private final String myNick;
    private final Consumer<String> send;
    private final JPanel list = Ui.clear(null);
    private final JLabel count = Ui.label(" ", Theme.SMALL_BOLD, Theme.PINK_DARK);
    private final JTextField taskField = Ui.field(20);
    private final Ui.Btn assignButton = new Ui.Btn(NOBODY, Ui.Btn.Kind.SOFT);
    private String assignChoice = "";
    private List<String> online = new ArrayList<>();

    TaskPanel(String myNick, Consumer<String> send) {
        super(new BorderLayout(0, 10));
        this.myNick = myNick;
        this.send = send;
        setOpaque(false);

        JPanel head = Ui.clear(new BorderLayout(10, 0));
        head.add(Ui.label("Tasks", Theme.H2, Theme.PINK_DARK), BorderLayout.WEST);
        JPanel countBox = Ui.clear(new FlowLayout(FlowLayout.LEFT, 0, 6));
        countBox.add(count);
        head.add(countBox, BorderLayout.CENTER);
        add(head, BorderLayout.NORTH);

        list.setLayout(new BoxLayout(list, BoxLayout.Y_AXIS));
        JPanel top = Ui.clear(new BorderLayout());
        top.add(list, BorderLayout.NORTH);
        add(Ui.scroll(top), BorderLayout.CENTER);

        // add bar
        Ui.Card bar = new Ui.Card(Color.WHITE, 26);
        bar.setLayout(new BorderLayout(8, 0));
        bar.setBorder(Theme.pad(8, 10));
        taskField.setBorder(Theme.pad(8, 10));
        taskField.setOpaque(false);
        Ui.Btn add = new Ui.Btn("Add task", Ui.Btn.Kind.PRIMARY);
        Runnable submit = () -> {
            String t = taskField.getText().trim();
            if (!t.isEmpty()) {
                send.accept(Protocol.build("T_ADD", t, assignChoice));
                taskField.setText("");
            }
        };
        add.addActionListener(e -> submit.run());
        taskField.addActionListener(e -> submit.run());
        assignButton.addActionListener(e -> chooseAssignee(assignButton, name -> {
            assignChoice = name;
            assignButton.setText(name.isEmpty() ? NOBODY : name);
        }));
        JPanel east = Ui.clear(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        east.add(Ui.label("for", Theme.SMALL, Theme.MUTED));
        east.add(assignButton);
        east.add(add);
        bar.add(taskField, BorderLayout.CENTER);
        bar.add(east, BorderLayout.EAST);
        add(bar, BorderLayout.SOUTH);
    }

    /** Pops up the list of people online (plus "nobody") under a button. */
    private void chooseAssignee(Ui.Btn anchor, Consumer<String> chosen) {
        JPopupMenu menu = new JPopupMenu();
        JMenuItem none = new JMenuItem(NOBODY);
        none.addActionListener(e -> chosen.accept(""));
        menu.add(none);
        for (String n : online) {
            JMenuItem item = new JMenuItem("<html>" + Theme.name(n) + "</html>");
            item.addActionListener(e -> chosen.accept(n));
            menu.add(item);
        }
        menu.show(anchor, 0, anchor.getHeight());
    }

    /** Names offered when assigning (the people online). */
    void setOnline(List<String> names) {
        online = new ArrayList<>(names);
        if (!assignChoice.isEmpty() && !containsIgnoreCase(online, assignChoice)) {
            assignChoice = "";
            assignButton.setText(NOBODY);
        }
    }

    private static boolean containsIgnoreCase(List<String> names, String n) {
        for (String x : names) {
            if (x.equalsIgnoreCase(n)) {
                return true;
            }
        }
        return false;
    }

    /** Rebuilds the checklist from the latest T_SET messages. */
    void setTasks(Collection<String[]> tasks) {
        list.removeAll();
        int todo = 0;
        int done = 0;
        List<String[]> sorted = new ArrayList<>(tasks);
        sorted.sort((a, b) -> {
            boolean da = "DONE".equals(Protocol.arg(a, 5));
            boolean db = "DONE".equals(Protocol.arg(b, 5));
            if (da != db) {
                return da ? 1 : -1;                 // open tasks first
            }
            return Integer.compare(id(a), id(b));
        });
        for (String[] t : sorted) {
            if ("DONE".equals(Protocol.arg(t, 5))) {
                done++;
            } else {
                todo++;
            }
            list.add(buildRow(t));
            list.add(Box.createVerticalStrut(8));
        }
        if (sorted.isEmpty()) {
            JLabel empty = Ui.label("No tasks yet. Add the first one below.", Theme.BASE, Theme.MUTED);
            empty.setBorder(Theme.pad(30, 6));
            list.add(empty);
        }
        count.setText(todo + " to do  |  " + done + " done");
        list.revalidate();
        list.repaint();
    }

    private JPanel buildRow(String[] t) {
        final int id = id(t);
        String creator = Protocol.arg(t, 2);
        String assignee = Protocol.arg(t, 4);
        boolean done = "DONE".equals(Protocol.arg(t, 5));
        boolean mine = assignee.equalsIgnoreCase(myNick);
        boolean iAdded = creator.equalsIgnoreCase(myNick);

        Ui.Card row = new Ui.Card(done ? Theme.mix(Theme.ROSE, Color.WHITE, 0.5f) : Color.WHITE, 22);
        row.setLayout(new BorderLayout(12, 0));
        row.setBorder(Theme.pad(10, 14));

        JPanel dot = Ui.clear(new BorderLayout());
        dot.add(new Ui.CheckDot(done), BorderLayout.NORTH);
        row.add(dot, BorderLayout.WEST);

        JPanel text = Ui.clear(new BorderLayout(0, 2));
        text.add(new Ui.TitleLabel(Protocol.arg(t, 3), done), BorderLayout.NORTH);
        text.add(Ui.label("<html>#" + id + " &nbsp;added by " + Theme.name(creator) + "</html>",
                Theme.SMALL, Theme.MUTED), BorderLayout.CENTER);
        row.add(text, BorderLayout.CENTER);

        JPanel right = Ui.clear(new FlowLayout(FlowLayout.RIGHT, 4, 0));
        if (assignee.isEmpty()) {
            right.add(new Ui.Pill("nobody yet", Theme.BLUSH, Theme.MUTED));
        } else {
            right.add(new Ui.Pill(assignee + (mine ? " (you)" : ""), Theme.mix(Theme.nameColor(assignee), Color.WHITE, 0.85f),
                    Theme.nameColor(assignee)));
        }
        if (!done && assignee.isEmpty()) {
            right.add(action("Take it", () -> send.accept(Protocol.build("T_TAKE", String.valueOf(id)))));
        }
        if (!done && (mine || iAdded)) {
            right.add(action("Done", () -> send.accept(Protocol.build("T_DONE", String.valueOf(id)))));
        }
        if (!done && iAdded) {
            Ui.Btn reassign = new Ui.Btn("Reassign", Ui.Btn.Kind.GHOST);
            reassign.addActionListener(e -> chooseAssignee(reassign,
                    name -> send.accept(Protocol.build("T_ASSIGN", String.valueOf(id), name))));
            right.add(reassign);
        }
        if (iAdded) {
            right.add(action("Remove", () -> send.accept(Protocol.build("T_DEL", String.valueOf(id)))));
        }
        JPanel rightBox = Ui.clear(new BorderLayout());
        rightBox.add(right, BorderLayout.CENTER);
        row.add(rightBox, BorderLayout.EAST);

        row.setAlignmentX(LEFT_ALIGNMENT);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, row.getPreferredSize().height));
        return row;
    }

    private Ui.Btn action(String text, Runnable run) {
        Ui.Btn b = new Ui.Btn(text, Ui.Btn.Kind.GHOST);
        b.addActionListener(e -> run.run());
        return b;
    }

    private static int id(String[] t) {
        try {
            return Integer.parseInt(Protocol.arg(t, 1));
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
