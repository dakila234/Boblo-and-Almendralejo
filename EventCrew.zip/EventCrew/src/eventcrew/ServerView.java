package eventcrew;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Collections;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/** Server window: choose the port, start or stop the server, watch the log. */
class ServerView extends JPanel implements ChatServer.Listener {

    private final ChatServer server = new ChatServer(this);
    private final JTextField portField = Ui.field(6);
    private final Ui.Btn toggleButton = new Ui.Btn("Start server", Ui.Btn.Kind.PRIMARY);
    private final JLabel statusLabel = Ui.label("Stopped", Theme.BOLD, Theme.RED);
    private final JLabel usersLabel = Ui.label("0 online", Theme.BOLD, Theme.PINK_DARK);
    private final JTextArea logArea = new JTextArea();

    ServerView() {
        super(new BorderLayout(0, 14));
        setBackground(Theme.BLUSH);
        setBorder(BorderFactory.createEmptyBorder(18, 22, 18, 22));
        portField.setText(String.valueOf(Protocol.DEFAULT_PORT));

        JPanel header = Ui.clear(new BorderLayout());
        header.add(Ui.label("Host console", Theme.H1, Theme.PINK_DARK), BorderLayout.WEST);
        header.add(usersLabel, BorderLayout.EAST);

        Ui.Card controls = new Ui.Card(Color.WHITE, 24);
        controls.setLayout(new BorderLayout(0, 8));
        controls.setBorder(Theme.pad(14, 16));
        JPanel row = Ui.clear(new FlowLayout(FlowLayout.LEFT, 10, 0));
        row.add(Ui.label("Port", Theme.SMALL_BOLD, Theme.MUTED));
        row.add(portField);
        row.add(toggleButton);
        row.add(statusLabel);
        controls.add(row, BorderLayout.NORTH);
        controls.add(Ui.label("Crew members on other computers join with: " + localAddresses(),
                Theme.SMALL, Theme.MUTED), BorderLayout.SOUTH);

        JPanel top = Ui.clear(new BorderLayout(0, 12));
        top.add(header, BorderLayout.NORTH);
        top.add(controls, BorderLayout.CENTER);
        add(top, BorderLayout.NORTH);

        logArea.setEditable(false);
        logArea.setLineWrap(true);
        logArea.setOpaque(false);
        logArea.setForeground(Theme.TEXT);
        logArea.setFont(new java.awt.Font(java.awt.Font.MONOSPACED, java.awt.Font.PLAIN, 13));
        Ui.Card logCard = new Ui.Card(Color.WHITE, 24);
        logCard.setLayout(new BorderLayout());
        logCard.setBorder(Theme.pad(12));
        logCard.add(Ui.scroll(logArea), BorderLayout.CENTER);
        add(logCard, BorderLayout.CENTER);

        toggleButton.addActionListener(e -> toggle());
        setPreferredSize(new java.awt.Dimension(620, 420));
    }

    void shutdown() {
        server.stop();
    }

    private void toggle() {
        if (server.isRunning()) {
            server.stop();
            toggleButton.setText("Start server");
            portField.setEnabled(true);
            statusLabel.setText("Stopped");
            statusLabel.setForeground(Theme.RED);
            return;
        }
        int port;
        try {
            port = Integer.parseInt(portField.getText().trim());
            if (port < 1024 || port > 65535) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Port must be a number from 1024 to 65535.",
                    "Invalid port", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            server.start(port);
            toggleButton.setText("Stop server");
            portField.setEnabled(false);
            statusLabel.setText("Running on port " + port);
            statusLabel.setForeground(Theme.PINK);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Could not start the server:\n" + ex.getMessage()
                    + "\n\nIs another server already using this port?",
                    "Start failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    /** Called from server threads, so hop onto the Swing thread. */
    @Override
    public void onLog(String message) {
        SwingUtilities.invokeLater(() -> {
            logArea.append(message + "\n");
            logArea.setCaretPosition(logArea.getDocument().getLength());
        });
    }

    @Override
    public void onUserCountChanged(int count) {
        SwingUtilities.invokeLater(() -> usersLabel.setText(count + " online"));
    }

    private static String localAddresses() {
        StringBuilder sb = new StringBuilder();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) {
                    continue;
                }
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address) {
                        if (sb.length() > 0) {
                            sb.append(", ");
                        }
                        sb.append(a.getHostAddress());
                    }
                }
            }
        } catch (SocketException ignored) {
            // just show nothing
        }
        return sb.length() == 0 ? "(no network found)" : sb.toString();
    }
}
