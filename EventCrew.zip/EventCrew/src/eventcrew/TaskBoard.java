package eventcrew;

import java.util.ArrayList;
import java.util.List;

/**
 * Server-side state of feature 1: task assignments.
 * Anyone can add a task, assign it to a crew member or leave it open; crew members can take an
 * open task and mark their own tasks done. Synchronized because many threads use it at once.
 */
class TaskBoard {

    private static final int MAX_TASKS = 200;

    private final List<Task> tasks = new ArrayList<>();
    private int nextId = 1;

    synchronized void reset() {
        tasks.clear();
        nextId = 1;
    }

    /** @param assignee a verified online crew member's name, or "" for nobody yet */
    synchronized Result add(String creator, String title, String assignee) {
        title = title == null ? "" : title.trim();
        if (title.isEmpty()) {
            return Result.fail("A task needs a title.");
        }
        if (title.length() > Protocol.MAX_TASK) {
            title = title.substring(0, Protocol.MAX_TASK);
        }
        if (tasks.size() >= MAX_TASKS) {
            return Result.fail("The task list is full.");
        }
        Task t = new Task(nextId++, creator, title);
        t.assignee = assignee;
        tasks.add(t);
        String to = assignee.isEmpty() ? "nobody yet" : assignee;
        return Result.ok(t.toLine(), creator + " added task #" + t.id + ": " + title + " (assigned to " + to + ").");
    }

    synchronized Result take(int id, String user) {
        Task t = find(id);
        if (t == null) {
            return Result.fail("No task with number " + id + ".");
        }
        if (t.done) {
            return Result.fail("Task #" + id + " is already done.");
        }
        if (!t.assignee.isEmpty() && !t.assignee.equalsIgnoreCase(user)) {
            return Result.fail("Task #" + id + " is already assigned to " + t.assignee + ".");
        }
        if (t.assignee.equalsIgnoreCase(user)) {
            return Result.fail("Task #" + id + " is already yours.");
        }
        t.assignee = user;
        return Result.ok(t.toLine(), user + " took task #" + id + ": " + t.title + ".");
    }

    /** Only the person who added the task can (re)assign it. @param assignee verified name or "" */
    synchronized Result assign(int id, String user, String assignee) {
        Task t = find(id);
        if (t == null) {
            return Result.fail("No task with number " + id + ".");
        }
        if (!t.creator.equalsIgnoreCase(user)) {
            return Result.fail("Only " + t.creator + " can assign task #" + id + ".");
        }
        if (t.done) {
            return Result.fail("Task #" + id + " is already done.");
        }
        t.assignee = assignee;
        String to = assignee.isEmpty() ? "nobody (open again)" : assignee;
        return Result.ok(t.toLine(), user + " assigned task #" + id + " to " + to + ".");
    }

    /** The assignee (or the person who added the task) can mark it done. */
    synchronized Result done(int id, String user) {
        Task t = find(id);
        if (t == null) {
            return Result.fail("No task with number " + id + ".");
        }
        if (t.done) {
            return Result.fail("Task #" + id + " is already done.");
        }
        boolean isAssignee = t.assignee.equalsIgnoreCase(user);
        boolean isCreator = t.creator.equalsIgnoreCase(user);
        if (!isAssignee && !isCreator) {
            return Result.fail("Only " + (t.assignee.isEmpty() ? t.creator : t.assignee) + " can finish task #" + id + ".");
        }
        if (t.assignee.isEmpty() && !isCreator) {
            return Result.fail("Take task #" + id + " first.");
        }
        t.done = true;
        return Result.ok(t.toLine(), user + " finished task #" + id + ": " + t.title + ".");
    }

    synchronized Result remove(int id, String user) {
        Task t = find(id);
        if (t == null) {
            return Result.fail("No task with number " + id + ".");
        }
        if (!t.creator.equalsIgnoreCase(user)) {
            return Result.fail("Only " + t.creator + " can remove task #" + id + ".");
        }
        t.removed = true;
        return Result.ok(t.toLine(), user + " removed task #" + id + ".");
    }

    /** All current tasks as protocol lines (used when a new client joins). */
    synchronized List<String> snapshotLines() {
        List<String> lines = new ArrayList<>();
        for (Task t : tasks) {
            if (!t.removed) {
                lines.add(t.toLine());
            }
        }
        return lines;
    }

    private Task find(int id) {
        for (Task t : tasks) {
            if (t.id == id && !t.removed) {
                return t;
            }
        }
        return null;
    }
}
