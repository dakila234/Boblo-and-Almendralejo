package eventcrew;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.AbstractBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.plaf.basic.BasicScrollBarUI;

/** Small custom-painted pieces for the pink look: pill buttons, rounded cards, check circles. */
final class Ui {

    private Ui() { }

    static Graphics2D smooth(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        return g2;
    }

    static JLabel label(String text, Font font, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(font);
        l.setForeground(color);
        return l;
    }

    static JPanel clear(java.awt.LayoutManager layout) {
        JPanel p = new JPanel(layout);
        p.setOpaque(false);
        return p;
    }

    /** Read-only text that wraps at a fixed pixel width. */
    static JTextArea wrap(String text, int width, Font font, Color color) {
        JTextArea t = new JTextArea(text);
        t.setEditable(false);
        t.setFocusable(false);
        t.setOpaque(false);
        t.setLineWrap(true);
        t.setWrapStyleWord(true);
        t.setFont(font);
        t.setForeground(color);
        t.setBorder(null);
        t.setSize(new Dimension(width, 1));
        Dimension d = new Dimension(width, t.getPreferredSize().height);
        t.setPreferredSize(d);
        t.setMinimumSize(d);
        t.setMaximumSize(d);
        return t;
    }

    /** Rounded outline used around text fields. */
    static final class RoundBorder extends AbstractBorder {
        private final Color color;

        RoundBorder(Color color) {
            this.color = color;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = smooth(g);
            g2.setColor(color);
            g2.drawRoundRect(x, y, w - 1, h - 1, h, h);
            g2.dispose();
        }
    }

    static void styleField(JTextField f) {
        f.setOpaque(true);
        f.setBackground(Color.WHITE);
        f.setForeground(Theme.TEXT);
        f.setCaretColor(Theme.PINK);
        f.setSelectionColor(Theme.ROSE);
        f.setSelectedTextColor(Theme.TEXT);
        f.setFont(Theme.BASE);
        f.setBorder(new CompoundBorder(new RoundBorder(Theme.LINE), Theme.pad(8, 14)));
    }

    static JTextField field(int columns) {
        JTextField f = new JTextField(columns);
        styleField(f);
        return f;
    }

    static JScrollPane scroll(Component c) {
        JScrollPane s = new JScrollPane(c);
        s.setBorder(null);
        s.setOpaque(false);
        s.getViewport().setOpaque(false);
        s.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        s.getVerticalScrollBar().setUI(new ThinBar());
        s.getVerticalScrollBar().setPreferredSize(new Dimension(8, 0));
        s.getVerticalScrollBar().setUnitIncrement(18);
        return s;
    }

    // ---------------------------------------------------------------------------------------

    /** Pill-shaped button. PRIMARY = pink, SOFT = pale pink with pink text, GHOST = text only. */
    static final class Btn extends JButton {
        enum Kind { PRIMARY, SOFT, GHOST }

        private final Kind kind;
        private boolean hover;

        Btn(String text, Kind kind) {
            super(text);
            this.kind = kind;
            setOpaque(false);
            setContentAreaFilled(false);
            setFocusPainted(false);
            setBorder(kind == Kind.GHOST ? Theme.pad(5, 8) : Theme.pad(9, 18));
            setFont(kind == Kind.GHOST ? Theme.SMALL_BOLD : Theme.BOLD);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) { hover = true; repaint(); }

                @Override
                public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = smooth(g);
            int w = getWidth();
            int h = getHeight();
            Color fg;
            if (kind == Kind.PRIMARY) {
                Color base = !isEnabled() ? Theme.mix(Theme.PINK, Color.WHITE, 0.6f)
                        : getModel().isPressed() ? Theme.PINK_DARK
                        : hover ? Theme.mix(Theme.PINK, Color.WHITE, 0.12f) : Theme.PINK;
                g2.setColor(base);
                g2.fillRoundRect(0, 0, w, h, h, h);
                fg = Color.WHITE;
            } else if (kind == Kind.SOFT) {
                g2.setColor(hover && isEnabled() ? Theme.ROSE : Theme.mix(Theme.ROSE, Color.WHITE, 0.55f));
                g2.fillRoundRect(0, 0, w, h, h, h);
                g2.setColor(Theme.LINE);
                g2.drawRoundRect(0, 0, w - 1, h - 1, h, h);
                fg = isEnabled() ? Theme.PINK_DARK : Theme.MUTED;
            } else {
                if (hover && isEnabled()) {
                    g2.setColor(Theme.mix(Theme.ROSE, Color.WHITE, 0.4f));
                    g2.fillRoundRect(0, 0, w, h, h, h);
                }
                fg = isEnabled() ? Theme.PINK_DARK : Theme.MUTED;
            }
            g2.dispose();
            setForeground(fg);
            super.paintComponent(g);
        }
    }

    /** Rounded white (or tinted) card with a soft pink outline. */
    static class Card extends JPanel {
        private Color fill;
        private final int arc;

        Card(Color fill, int arc) {
            this.fill = fill;
            this.arc = arc;
            setOpaque(false);
        }

        void fill(Color c) {
            this.fill = c;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = smooth(g);
            g2.setColor(fill);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), arc, arc);
            g2.setColor(Theme.LINE);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arc, arc);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    /** Small rounded tag. */
    static final class Pill extends JLabel {
        private final Color bg;

        Pill(String text, Color bg, Color fg) {
            super(text);
            this.bg = bg;
            setOpaque(false);
            setForeground(fg);
            setFont(Theme.SMALL_BOLD);
            setBorder(Theme.pad(3, 11));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = smooth(g);
            g2.setColor(bg);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
            g2.dispose();
            super.paintComponent(g);
        }
    }

    /** Round badge with a person's initial, in their name colour. */
    static final class Avatar extends JComponent {
        private final String name;

        Avatar(String name, int size) {
            this.name = name == null || name.isEmpty() ? "?" : name;
            Dimension d = new Dimension(size, size);
            setPreferredSize(d);
            setMinimumSize(d);
            setMaximumSize(d);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = smooth(g);
            int s = Math.min(getWidth(), getHeight());
            g2.setColor(Theme.nameColor(name));
            g2.fillOval(0, 0, s, s);
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("SansSerif", Font.BOLD, Math.round(s * 0.5f)));
            FontMetrics fm = g2.getFontMetrics();
            String initial = name.substring(0, 1).toUpperCase();
            g2.drawString(initial, (s - fm.stringWidth(initial)) / 2f, (s - fm.getHeight()) / 2f + fm.getAscent());
            g2.dispose();
        }
    }

    /** Round check box shown at the left of a task: empty circle, or pink circle with a tick when done. */
    static final class CheckDot extends JComponent {
        private final boolean done;

        CheckDot(boolean done) {
            this.done = done;
            Dimension d = new Dimension(26, 26);
            setPreferredSize(d);
            setMinimumSize(d);
            setMaximumSize(d);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = smooth(g);
            int s = Math.min(getWidth(), getHeight());
            if (done) {
                g2.setColor(Theme.PINK);
                g2.fillOval(1, 1, s - 2, s - 2);
                g2.setColor(Color.WHITE);
                g2.setStroke(new BasicStroke(2.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.drawLine(s * 28 / 100, s * 52 / 100, s * 44 / 100, s * 68 / 100);
                g2.drawLine(s * 44 / 100, s * 68 / 100, s * 74 / 100, s * 33 / 100);
            } else {
                g2.setColor(Theme.LINE);
                g2.setStroke(new BasicStroke(2f));
                g2.drawOval(1, 1, s - 3, s - 3);
            }
            g2.dispose();
        }
    }

    /** Status dot: pink when ready, grey while waiting. */
    static final class Dot extends JComponent {
        private boolean on;

        Dot(boolean on) {
            this.on = on;
            Dimension d = new Dimension(12, 12);
            setPreferredSize(d);
            setMinimumSize(d);
            setMaximumSize(d);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = smooth(g);
            if (on) {
                g2.setColor(Theme.PINK);
                g2.fillOval(0, 0, 11, 11);
            } else {
                g2.setColor(Theme.LINE);
                g2.setStroke(new BasicStroke(2f));
                g2.drawOval(1, 1, 9, 9);
            }
            g2.dispose();
        }
    }

    /** Task title that is crossed out when the task is done. */
    static final class TitleLabel extends JLabel {
        private final boolean strike;

        TitleLabel(String text, boolean strike) {
            super(text);
            this.strike = strike;
            setFont(Theme.BOLD.deriveFont(15f));
            setForeground(strike ? Theme.MUTED : Theme.TEXT);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (strike) {
                Graphics2D g2 = smooth(g);
                FontMetrics fm = g2.getFontMetrics(getFont());
                int w = Math.min(fm.stringWidth(getText()), getWidth());
                int y = getHeight() / 2;
                g2.setColor(Theme.MUTED);
                g2.drawLine(0, y, w, y);
                g2.dispose();
            }
        }
    }

    /** Thin progress bar. */
    static final class Bar extends JComponent {
        private float share;

        Bar() {
            setPreferredSize(new Dimension(100, 8));
            setMinimumSize(new Dimension(20, 8));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 8));
        }

        void set(float share) {
            this.share = Math.max(0f, Math.min(1f, share));
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = smooth(g);
            int h = getHeight();
            g2.setColor(Theme.ROSE);
            g2.fillRoundRect(0, 0, getWidth(), h, h, h);
            int w = Math.round(getWidth() * share);
            if (w > 0) {
                g2.setColor(Theme.PINK);
                g2.fillRoundRect(0, 0, Math.max(w, h), h, h, h);
            }
            g2.dispose();
        }
    }

    /** Slim pink scroll bar. */
    static final class ThinBar extends BasicScrollBarUI {
        @Override
        protected void configureScrollBarColors() {
            thumbColor = Theme.LINE;
            trackColor = Theme.BLUSH;
        }

        @Override
        protected JButton createDecreaseButton(int orientation) {
            return zero();
        }

        @Override
        protected JButton createIncreaseButton(int orientation) {
            return zero();
        }

        private static JButton zero() {
            JButton b = new JButton();
            b.setPreferredSize(new Dimension(0, 0));
            b.setMinimumSize(new Dimension(0, 0));
            b.setMaximumSize(new Dimension(0, 0));
            return b;
        }

        @Override
        protected void paintTrack(Graphics g, JComponent c, Rectangle r) {
            // transparent track
        }

        @Override
        protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
            if (r.isEmpty()) {
                return;
            }
            Graphics2D g2 = smooth(g);
            g2.setColor(Theme.LINE);
            g2.fillRoundRect(r.x + 1, r.y + 1, r.width - 2, r.height - 2, 8, 8);
            g2.dispose();
        }
    }
}
