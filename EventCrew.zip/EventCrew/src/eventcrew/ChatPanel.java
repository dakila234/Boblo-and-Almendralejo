package eventcrew;

import java.awt.BorderLayout;
import java.awt.Color;
import java.util.function.Consumer;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

/** Crew chat: a rounded pink card with the message log (coloured names) and a pill-shaped input. */
class ChatPanel extends JPanel {

    private final JTextPane log = new JTextPane();
    private final JTextField input = Ui.field(16);

    ChatPanel(Consumer<String> onInput) {
        super(new BorderLayout(0, 10));
        setOpaque(false);

        add(Ui.label("Crew chat", Theme.H2, Theme.PINK_DARK), BorderLayout.NORTH);

        Ui.Card card = new Ui.Card(Color.WHITE, 22);
        card.setLayout(new BorderLayout());
        card.setBorder(Theme.pad(12));
        log.setEditable(false);
        log.setOpaque(false);
        JScrollPane scroll = Ui.scroll(log);
        card.add(scroll, BorderLayout.CENTER);
        add(card, BorderLayout.CENTER);

        Ui.Btn send = new Ui.Btn("Send", Ui.Btn.Kind.PRIMARY);
        Runnable submit = () -> {
            String t = input.getText().trim();
            if (!t.isEmpty()) {
                input.setText("");
                onInput.accept(t);
            }
        };
        send.addActionListener(e -> submit.run());
        input.addActionListener(e -> submit.run());
        JPanel bottom = Ui.clear(new BorderLayout(8, 0));
        bottom.add(input, BorderLayout.CENTER);
        bottom.add(send, BorderLayout.EAST);
        add(bottom, BorderLayout.SOUTH);
    }

    private void append(String text, Color color, boolean bold, boolean italic) {
        StyledDocument doc = log.getStyledDocument();
        SimpleAttributeSet a = new SimpleAttributeSet();
        StyleConstants.setForeground(a, color);
        StyleConstants.setBold(a, bold);
        StyleConstants.setItalic(a, italic);
        StyleConstants.setFontSize(a, 14);
        try {
            doc.insertString(doc.getLength(), text, a);
        } catch (BadLocationException ignored) {
            // cannot happen: we always insert at the end
        }
        log.setCaretPosition(doc.getLength());   // auto-scroll
    }

    void chat(String time, String sender, String text) {
        append("[" + time + "] ", Theme.MUTED, false, false);
        append(sender, Theme.nameColor(sender), true, false);
        append(": ", Theme.TEXT, false, false);
        append(text + "\n", Theme.TEXT, false, false);
    }

    void privateMessage(String time, String from, String to, String text) {
        append("[" + time + "] ", Theme.MUTED, false, false);
        append("(private) ", Theme.PINK, false, true);
        append(from, Theme.nameColor(from), true, false);
        append(" -> ", Theme.TEXT, false, false);
        append(to, Theme.nameColor(to), true, false);
        append(": ", Theme.TEXT, false, false);
        append(text + "\n", Theme.PINK_DARK, false, true);
    }

    void system(String text) {
        append("* " + text + "\n", Theme.MUTED, false, true);
    }

    void error(String text) {
        append("! " + text + "\n", Theme.RED, true, false);
    }

    void prefill(String text) {
        input.setText(text);
        input.requestFocusInWindow();
    }

    void focusInput() {
        input.requestFocusInWindow();
    }
}
