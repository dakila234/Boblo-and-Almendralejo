package eventcrew;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/**
 * The whole Event Crew screen on one page, no tabs: crew readiness on the left, the task list
 * in the middle and the chat on the right. Server messages arrive on the reader thread and are
 * moved to the Swing thread with SwingUtilities.invokeLater before any GUI is touched.
 */
class MainView extends JPanel implements ClientConnection.Listener {

    private final ClientConnection connection;
    private final String nick;
    private final Runnable onExit;

    private final CrewStrip roster;
    private final TaskPanel taskPanel;
    private final ChatPanel chat;
    private final JLabel taskCount = new JLabel(" ");
    private final Map<Integer, String[]> tasks = new LinkedHashMap<>();

    private boolean connected = true;

    /** @param onExit called after the user leaves or the connection is lost (shows the join screen again) */
    MainView(ClientConnection connection, String nick, String host, int port, Runnable onExit) {
        super(new BorderLayout());
        this.connection = connection;
        this.nick = nick;
        this.onExit = onExit;

        roster = new CrewStrip(nick, connection::send);
        taskPanel = new TaskPanel(nick, connection::send);
        chat = new ChatPanel(this::submitInput);
        chat.setPreferredSize(new Dimension(330, 0));

        // pink header band
        JPanel band = new JPanel(new BorderLayout());
        band.setBackground(Theme.PINK);
        band.setBorder(BorderFactory.createEmptyBorder(11, 18, 11, 18));
        JLabel title = new JLabel("EVENT CREW");
        title.setForeground(Color.WHITE);
        title.setFont(title.getFont().deriveFont(java.awt.Font.BOLD, 19f));
        band.add(title, BorderLayout.WEST);
        taskCount.setForeground(new Color(0xFFE3F0));
        taskCount.setHorizontalAlignment(JLabel.CENTER);
        band.add(taskCount, BorderLayout.CENTER);
        JLabel who = new JLabel("<html><font color='#FFE3F0'>Signed in as</font> <b><font color='#FFFFFF'>"
                + Theme.esc(nick) + "</font></b> <font color='#FFE3F0'>@ " + Theme.esc(host) + ":" + port
                + "</font></html>");
        band.add(who, BorderLayout.EAST);

        // body: crew strip on top, tasks and chat below
        JPanel body = Ui.clear(new BorderLayout(0, 14));
        body.setBorder(BorderFactory.createEmptyBorder(14, 18, 16, 18));
        body.add(roster, BorderLayout.NORTH);
        JPanel lower = Ui.clear(new BorderLayout(18, 0));
        lower.add(taskPanel, BorderLayout.CENTER);
        chat.setPreferredSize(new Dimension(350, 0));
        lower.add(chat, BorderLayout.EAST);
        body.add(lower, BorderLayout.CENTER);

        setBackground(Theme.BLUSH);
        add(band, BorderLayout.NORTH);
        add(body, BorderLayout.CENTER);
        setPreferredSize(new Dimension(1120, 680));

        chat.system("Welcome to Event Crew, " + nick + ". Type /help to see commands.");
        refreshTasks();
        connection.startReading(this);   // start only after the GUI exists
    }

    // ---- sending -------------------------------------------------------------------------

    private void submitInput(String text) {
        if (!connected) {
            return;
        }
        if (text.startsWith("/")) {
            runCommand(text);
        } else {
            connection.send(Protocol.build("MSG", text));
        }
    }

    /** Slash commands typed in the chat box. */
    private void runCommand(String text) {
        String[] parts = text.split("\\s+", 3);
        String arg1 = parts.length > 1 ? parts[1] : "";
        switch (parts[0].toLowerCase()) {
            case "/help":
                chat.system("Commands: /list  /msg <nick> <text>  /quit  /task Title | person  /take <#>  /done <#>  "
                        + "/assign <#> <person>  /deltask <#>  /check <what>  /ready  /notready");
                break;
            case "/list":
                connection.send(Protocol.build("LIST"));
                break;
            case "/quit":
                leave();
                break;
            case "/msg":
                if (parts.length < 3) {
                    chat.error("Usage: /msg <nickname> <text>");
                } else {
                    connection.send(Protocol.build("PM", parts[1], parts[2]));
                }
                break;
            case "/task": {
                String body = text.length() > 5 ? text.substring(5) : "";
                int bar = body.indexOf('|');
                String title = bar < 0 ? body.trim() : body.substring(0, bar).trim();
                String person = bar < 0 ? "" : body.substring(bar + 1).trim();
                connection.send(Protocol.build("T_ADD", title, person));
                break;
            }
            case "/take":
                connection.send(Protocol.build("T_TAKE", arg1));
                break;
            case "/done":
                connection.send(Protocol.build("T_DONE", arg1));
                break;
            case "/assign":
                connection.send(Protocol.build("T_ASSIGN", arg1, parts.length > 2 ? parts[2].trim() : ""));
                break;
            case "/deltask":
                connection.send(Protocol.build("T_DEL", arg1));
                break;
            case "/check":
                connection.send(Protocol.build("R_CHECK", text.length() > 6 ? text.substring(6).trim() : ""));
                break;
            case "/ready":
                connection.send(Protocol.build("R_ACK", "1"));
                break;
            case "/notready":
                connection.send(Protocol.build("R_ACK", "0"));
                break;
            default:
                chat.error("Unknown command. Type /help.");
        }
    }

    /** Help > Commands. */
    void showCommands() {
        JOptionPane.showMessageDialog(this,
                "/list                          who is online\n"
                + "/msg <person> <text>     private message\n"
                + "/quit                          leave\n"
                + "/task Title | person      add a task (person is optional)\n"
                + "/take <#>                    take an open task\n"
                + "/done <#>                   mark a task done\n"
                + "/assign <#> <person>   assign a task you added\n"
                + "/deltask <#>                remove a task you added\n"
                + "/check <what>             start a readiness check\n"
                + "/ready   /notready       answer the readiness check",
                "Commands", JOptionPane.INFORMATION_MESSAGE);
    }

    void leave() {
        if (connected) {
            connected = false;
            connection.disconnect();
        }
        onExit.run();
    }

    // ---- receiving (ClientConnection.Listener) --------------------------------------------

    @Override
    public void onMessage(String[] p) {
        SwingUtilities.invokeLater(() -> handleMessage(p));
    }

    @Override
    public void onClosed() {
        SwingUtilities.invokeLater(() -> {
            if (!connected) {
                return;
            }
            connected = false;
            chat.error("Lost connection to the server.");
            JOptionPane.showMessageDialog(this, "The connection to the server was lost.\n"
                    + "You will be taken back to the join screen.",
                    "Disconnected", JOptionPane.WARNING_MESSAGE);
            onExit.run();
        });
    }

    void handleMessage(String[] p) {
        switch (p[0]) {
            case "MSG":
                chat.chat(Protocol.arg(p, 1), Protocol.arg(p, 2), Protocol.arg(p, 3));
                break;
            case "SYS":
                chat.system(Protocol.arg(p, 2));
                break;
            case "PM":
                chat.privateMessage(Protocol.arg(p, 1), Protocol.arg(p, 2), Protocol.arg(p, 3), Protocol.arg(p, 4));
                break;
            case "ERR":
                chat.error(Protocol.arg(p, 1));
                break;
            case "USERS":
                taskPanel.setOnline(new ArrayList<>(Arrays.asList(p).subList(1, p.length)));
                break;
            case "R_STATE":
                roster.setReadiness(p);
                break;
            case "E_RESET":
                tasks.clear();
                refreshTasks();
                break;
            case "T_SET": {
                int id;
                try {
                    id = Integer.parseInt(Protocol.arg(p, 1));
                } catch (NumberFormatException e) {
                    break;
                }
                if ("REMOVED".equals(Protocol.arg(p, 5))) {
                    tasks.remove(id);
                } else {
                    tasks.put(id, p);
                }
                refreshTasks();
                break;
            }
            default:
                break;
        }
    }

    private void refreshTasks() {
        taskPanel.setTasks(tasks.values());
        Map<String, Integer> open = new HashMap<>();
        int done = 0;
        int todo = 0;
        for (String[] t : tasks.values()) {
            if ("DONE".equals(Protocol.arg(t, 5))) {
                done++;
            } else {
                todo++;
                String who = Protocol.arg(t, 4);
                if (!who.isEmpty()) {
                    open.merge(who.toLowerCase(Locale.ROOT), 1, Integer::sum);
                }
            }
        }
        roster.setOpenTasks(open);
        taskCount.setText(todo + " to do  |  " + done + " done");
    }
}
