package eventcrew;

/** One task on the crew's task list. Only accessed through TaskBoard. */
class Task {
    final int id;
    final String creator;
    final String title;
    String assignee = "";       // empty = nobody yet
    boolean done;
    boolean removed;

    Task(int id, String creator, String title) {
        this.id = id;
        this.creator = creator;
        this.title = title;
    }

    /** T_SET|id|creator|title|assignee|state (state is TODO, DONE or REMOVED). */
    String toLine() {
        return Protocol.build("T_SET", String.valueOf(id), creator, title, assignee,
                removed ? "REMOVED" : done ? "DONE" : "TODO");
    }
}
