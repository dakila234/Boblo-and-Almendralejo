package eventcrew;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Server-side state of feature 2: readiness acknowledgments.
 * Everyone online is either READY or PENDING. Anyone can start a readiness check (for example
 * "Sound check at 3 PM"), which sets everyone back to PENDING; each crew member then acknowledges
 * by pressing "I'm ready". Synchronized because many threads use it at once.
 */
class ReadinessBoard {

    private int round = 0;
    private String label = "Standing readiness";
    private String startedBy = "";
    private final Set<String> ready = new HashSet<>();   // lower-case nicknames

    synchronized void reset() {
        round = 0;
        label = "Standing readiness";
        startedBy = "";
        ready.clear();
    }

    synchronized Result startCheck(String user, String text) {
        text = text == null ? "" : text.trim();
        if (text.isEmpty()) {
            text = "Readiness check";
        }
        if (text.length() > Protocol.MAX_LABEL) {
            text = text.substring(0, Protocol.MAX_LABEL);
        }
        round++;
        label = text;
        startedBy = user;
        ready.clear();
        return Result.ok(null, user + " started readiness check #" + round + ": " + text
                + ". Press I'm ready when you are.");
    }

    synchronized void setReady(String user, boolean isReady) {
        String key = user.toLowerCase(Locale.ROOT);
        if (isReady) {
            ready.add(key);
        } else {
            ready.remove(key);
        }
    }

    synchronized void remove(String user) {
        ready.remove(user.toLowerCase(Locale.ROOT));
    }

    /** R_STATE|round|label|startedBy|name|READY or PENDING|name|state... for the people online. */
    synchronized String stateLine(List<String> onlineNames) {
        List<String> f = new ArrayList<>();
        f.add(String.valueOf(round));
        f.add(label);
        f.add(startedBy);
        for (String n : onlineNames) {
            f.add(n);
            f.add(ready.contains(n.toLowerCase(Locale.ROOT)) ? "READY" : "PENDING");
        }
        return Protocol.build("R_STATE", f.toArray(new String[0]));
    }
}
