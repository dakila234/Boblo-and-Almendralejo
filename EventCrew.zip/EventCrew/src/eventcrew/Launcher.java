package eventcrew;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/** Starting window: start the server or open a client. */
public class Launcher extends JFrame {

    public Launcher() {
        super("Event Crew");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setContentPane(buildView());
        pack();
        setResizable(false);
        setLocationRelativeTo(null);
    }

    static JPanel buildView() {
        JPanel root = new JPanel(new BorderLayout(0, 18));
        root.setBackground(Theme.BLUSH);
        root.setBorder(BorderFactory.createEmptyBorder(26, 30, 26, 30));

        JPanel head = Ui.clear(new GridLayout(2, 1, 0, 2));
        head.add(Ui.label("Event Crew", Theme.H1, Theme.PINK_DARK));
        head.add(Ui.label("Assign tasks. Check that everyone is ready.", Theme.BASE, Theme.MUTED));
        root.add(head, BorderLayout.NORTH);

        Ui.Card card = new Ui.Card(Color.WHITE, 28);
        card.setLayout(new GridLayout(2, 1, 0, 12));
        card.setBorder(BorderFactory.createEmptyBorder(22, 24, 22, 24));
        Ui.Btn server = new Ui.Btn("Start Server (host computer)", Ui.Btn.Kind.PRIMARY);
        Ui.Btn client = new Ui.Btn("Open Client (join a crew)", Ui.Btn.Kind.SOFT);
        server.addActionListener(e -> new ServerFrame().setVisible(true));
        client.addActionListener(e -> new ConnectFrame().setVisible(true));
        card.add(server);
        card.add(client);
        root.add(card, BorderLayout.CENTER);

        root.add(Ui.label("Run the server once, then open a client for each person.", Theme.SMALL, Theme.MUTED),
                BorderLayout.SOUTH);
        root.setPreferredSize(new Dimension(420, 300));
        return root;
    }

    public static void main(String[] args) {
        Theme.apply();
        SwingUtilities.invokeLater(() -> new Launcher().setVisible(true));
    }
}
