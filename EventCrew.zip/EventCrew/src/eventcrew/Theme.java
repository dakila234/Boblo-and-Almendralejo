package eventcrew;

import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.UIManager;
import javax.swing.border.Border;

/** Pink look: hot pink accent, blush backgrounds, plum text. Every person also gets a name colour. */
final class Theme {

    static final Color PINK = new Color(0xE8368F);
    static final Color PINK_DARK = new Color(0xB5156A);
    static final Color ROSE = new Color(0xFFD3E6);
    static final Color BLUSH = new Color(0xFFF1F7);
    static final Color LINE = new Color(0xF3BCD5);
    static final Color TEXT = new Color(0x3A2030);
    static final Color MUTED = new Color(0x93707F);
    static final Color WHITE = Color.WHITE;
    static final Color RED = new Color(0xC62828);

    /** Name colours: pinks and purples plus a few contrasting ones so people are easy to tell apart. */
    private static final Color[] NAMES = {
        new Color(0xC2185B), new Color(0x6A1B9A), new Color(0x00897B), new Color(0xE65100),
        new Color(0x3949AB), new Color(0xAD1457), new Color(0x2E7D32), new Color(0x8E24AA)
    };

    static final Font BASE = new Font("SansSerif", Font.PLAIN, 14);
    static final Font BOLD = new Font("SansSerif", Font.BOLD, 14);
    static final Font SMALL = new Font("SansSerif", Font.PLAIN, 12);
    static final Font SMALL_BOLD = new Font("SansSerif", Font.BOLD, 12);
    static final Font H2 = new Font("SansSerif", Font.BOLD, 18);
    static final Font H1 = new Font("SansSerif", Font.BOLD, 26);

    private Theme() { }

    static void apply() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // keep the default look and feel
        }
        UIManager.put("Panel.background", BLUSH);
        UIManager.put("OptionPane.background", BLUSH);
        UIManager.put("OptionPane.messageForeground", TEXT);
    }

    static Border pad(int px) {
        return BorderFactory.createEmptyBorder(px, px, px, px);
    }

    static Border pad(int v, int h) {
        return BorderFactory.createEmptyBorder(v, h, v, h);
    }

    static Color mix(Color a, Color b, float t) {
        float u = 1f - t;
        return new Color(
                Math.round(a.getRed() * u + b.getRed() * t),
                Math.round(a.getGreen() * u + b.getGreen() * t),
                Math.round(a.getBlue() * u + b.getBlue() * t));
    }

    /** The colour of a person's name (the same name always gets the same colour). */
    static Color nameColor(String name) {
        int h = name == null ? 0 : name.toLowerCase().hashCode();
        return NAMES[Math.abs(h % NAMES.length)];
    }

    static String hex(Color c) {
        return String.format("#%02X%02X%02X", c.getRed(), c.getGreen(), c.getBlue());
    }

    static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    /** HTML snippet: a person's name, bold and in their colour. */
    static String name(String name) {
        return "<b><font color='" + hex(nameColor(name)) + "'>" + esc(name) + "</font></b>";
    }
}
