package eventcrew;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * Feature 2: readiness acknowledgments, shown as a strip across the top of the screen.
 * Each crew member is a chip (pink dot = ready, empty dot = waiting). Anyone can start a
 * readiness check; everyone then presses "I'm ready".
 */
class CrewStrip extends Ui.Card {

    private final String myNick;
    private final Consumer<String> send;
    private final JLabel checkLabel = new JLabel(" ");
    private final JLabel summary = new JLabel(" ");
    private final Ui.Bar bar = new Ui.Bar();
    private final JPanel chips = Ui.clear(new FlowLayout(FlowLayout.LEFT, 8, 4));
    private final Ui.Btn readyButton = new Ui.Btn("I'm ready", Ui.Btn.Kind.PRIMARY);
    private Map<String, Integer> openTasks = Collections.emptyMap();
    private String[] lastState;
    private boolean iAmReady = false;

    CrewStrip(String myNick, Consumer<String> send) {
        super(Color.WHITE, 22);
        this.myNick = myNick;
        this.send = send;
        setLayout(new BorderLayout(18, 0));
        setBorder(Theme.pad(12, 16));

        // left: what is being checked and how far along we are
        JPanel left = Ui.clear(new BorderLayout(0, 4));
        checkLabel.setFont(Theme.BOLD);
        checkLabel.setForeground(Theme.TEXT);
        summary.setFont(Theme.SMALL);
        summary.setForeground(Theme.MUTED);
        left.add(checkLabel, BorderLayout.NORTH);
        left.add(summary, BorderLayout.CENTER);
        JPanel barBox = Ui.clear(new BorderLayout());
        barBox.add(bar, BorderLayout.CENTER);
        left.add(barBox, BorderLayout.SOUTH);
        left.setPreferredSize(new java.awt.Dimension(260, 60));
        add(left, BorderLayout.WEST);

        // middle: one chip per crew member
        add(chips, BorderLayout.CENTER);

        // right: the two buttons
        Ui.Btn check = new Ui.Btn("Start check", Ui.Btn.Kind.SOFT);
        readyButton.addActionListener(e -> send.accept(Protocol.build("R_ACK", iAmReady ? "0" : "1")));
        check.addActionListener(e -> {
            String text = JOptionPane.showInputDialog(this, "What are you checking?\n(for example: Sound check at 3 PM)",
                    "Start a readiness check", JOptionPane.QUESTION_MESSAGE);
            if (text != null) {
                send.accept(Protocol.build("R_CHECK", text));
            }
        });
        JPanel buttons = Ui.clear(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        buttons.add(check);
        buttons.add(readyButton);
        add(buttons, BorderLayout.EAST);

        checkLabel.setText("Readiness");
        summary.setText("Waiting for the server...");
    }

    /** Open (not done) task counts per person, lower-case name to count. */
    void setOpenTasks(Map<String, Integer> counts) {
        this.openTasks = counts;
        if (lastState != null) {
            setReadiness(lastState);
        }
    }

    /** R_STATE|round|label|startedBy|name|READY or PENDING|name|state... */
    void setReadiness(String[] p) {
        lastState = p;
        int round = 0;
        try {
            round = Integer.parseInt(Protocol.arg(p, 1));
        } catch (NumberFormatException ignored) {
            // keep 0
        }
        String label = Protocol.arg(p, 2);
        String by = Protocol.arg(p, 3);

        chips.removeAll();
        int ready = 0;
        int total = 0;
        iAmReady = false;
        for (int i = 4; i + 1 < p.length; i += 2) {
            String name = p[i];
            boolean r = "READY".equals(p[i + 1]);
            total++;
            if (r) {
                ready++;
            }
            if (name.equalsIgnoreCase(myNick)) {
                iAmReady = r;
            }
            chips.add(chip(name, r));
        }

        checkLabel.setText("<html>" + (round == 0 ? Theme.esc(label)
                : "Check #" + round + ": " + Theme.esc(label) + " <font color='#93707F' size='-1'>by </font>"
                + Theme.name(by)) + "</html>");
        boolean all = total > 0 && ready == total;
        summary.setText(all ? "Everyone is ready!" : ready + " of " + total + " ready");
        summary.setForeground(all ? Theme.PINK_DARK : Theme.MUTED);
        summary.setFont(all ? Theme.BOLD : Theme.SMALL);
        bar.set(total == 0 ? 0f : ready / (float) total);
        fill(all ? Theme.ROSE : Color.WHITE);
        readyButton.setText(iAmReady ? "Not ready" : "I'm ready");
        chips.revalidate();
        chips.repaint();
    }

    private JPanel chip(String name, boolean ready) {
        Ui.Card c = new Ui.Card(ready ? Theme.mix(Theme.ROSE, Color.WHITE, 0.45f) : Theme.BLUSH, 22);
        c.setLayout(new FlowLayout(FlowLayout.LEFT, 6, 4));
        c.add(new Ui.Dot(ready));
        JLabel who = new JLabel("<html>" + Theme.name(name)
                + (name.equalsIgnoreCase(myNick) ? " <font color='#93707F'>(you)</font>" : "") + "</html>");
        who.setFont(Theme.BASE);
        c.add(who);
        int open = openTasks.getOrDefault(name.toLowerCase(Locale.ROOT), 0);
        JLabel state = Ui.label((ready ? "ready" : "waiting") + (open > 0 ? "  |  " + open + (open == 1 ? " task" : " tasks") : ""),
                Theme.SMALL, Theme.MUTED);
        c.add(state);
        return c;
    }
}
