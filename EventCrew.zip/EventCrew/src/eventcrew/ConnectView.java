package eventcrew;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingWorker;

/** Join screen: a pink card with server address, port and nickname. */
class ConnectView extends JPanel {

    interface Joined {
        void joined(ClientConnection connection, String nick, String host, int port);
    }

    private final Joined callback;
    private final JTextField hostField = Ui.field(18);
    private final JTextField portField = Ui.field(18);
    private final JTextField nickField = Ui.field(18);
    private final Ui.Btn joinButton = new Ui.Btn("Join the crew", Ui.Btn.Kind.PRIMARY);
    private final JLabel statusLabel = Ui.label(" ", Theme.SMALL, Theme.RED);

    ConnectView(Joined callback) {
        super(new GridBagLayout());
        this.callback = callback;
        setBackground(Theme.BLUSH);
        hostField.setText("localhost");
        portField.setText(String.valueOf(Protocol.DEFAULT_PORT));

        Ui.Card card = new Ui.Card(Color.WHITE, 30);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(Theme.pad(26, 32));
        card.add(left(Ui.label("EVENT CREW", Theme.SMALL_BOLD, Theme.PINK)));
        card.add(javax.swing.Box.createVerticalStrut(4));
        card.add(left(Ui.label("Join your crew", Theme.H1, Theme.TEXT)));
        card.add(javax.swing.Box.createVerticalStrut(18));
        addField(card, "Server address", hostField);
        addField(card, "Port", portField);
        addField(card, "Nickname", nickField);
        card.add(javax.swing.Box.createVerticalStrut(4));
        joinButton.setAlignmentX(LEFT_ALIGNMENT);
        joinButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        card.add(joinButton);
        card.add(javax.swing.Box.createVerticalStrut(8));
        card.add(left(statusLabel));
        card.setPreferredSize(new Dimension(380, 430));
        add(card);
        setPreferredSize(new Dimension(520, 520));

        joinButton.addActionListener(e -> connect());
        nickField.addActionListener(e -> connect());
    }

    private static void addField(JPanel card, String label, JTextField field) {
        card.add(left(Ui.label(label, Theme.SMALL_BOLD, Theme.MUTED)));
        card.add(javax.swing.Box.createVerticalStrut(4));
        field.setAlignmentX(LEFT_ALIGNMENT);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, field.getPreferredSize().height));
        card.add(field);
        card.add(javax.swing.Box.createVerticalStrut(12));
    }

    private static JLabel left(JLabel l) {
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }

    private void connect() {
        final String host = hostField.getText().trim();
        final String nick = nickField.getText().trim();
        final int port;

        if (host.isEmpty()) {
            showError("Enter the server address.");
            return;
        }
        try {
            port = Integer.parseInt(portField.getText().trim());
            if (port < 1 || port > 65535) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            showError("Port must be a number from 1 to 65535.");
            return;
        }
        String nickProblem = Protocol.validateNickname(nick);
        if (nickProblem != null) {
            showError(nickProblem);
            return;
        }

        setBusy(true);
        statusLabel.setForeground(Theme.MUTED);
        statusLabel.setText("Connecting...");

        // Networking runs off the Swing thread so the window never freezes.
        new SwingWorker<ClientConnection, Void>() {
            @Override
            protected ClientConnection doInBackground() throws Exception {
                ClientConnection conn = new ClientConnection();
                conn.connect(host, port, nick);
                return conn;
            }

            @Override
            protected void done() {
                try {
                    callback.joined(get(), nick, host, port);
                } catch (Exception ex) {
                    Throwable cause = ex.getCause() != null ? ex.getCause() : ex;
                    showError(friendly(cause));
                    setBusy(false);
                }
            }
        }.execute();
    }

    private static String friendly(Throwable t) {
        String m = t.getMessage();
        if (t instanceof java.net.ConnectException) {
            return "Could not reach the server. Is it running, and are the address and port right?";
        }
        if (t instanceof java.net.UnknownHostException) {
            return "Unknown server address: " + m;
        }
        if (t instanceof java.net.SocketTimeoutException) {
            return "The server did not answer in time.";
        }
        return m == null ? "Connection failed." : m;
    }

    private void showError(String message) {
        statusLabel.setForeground(Theme.RED);
        statusLabel.setText("<html><body style='width:300px'>" + Theme.esc(message) + "</body></html>");
    }

    private void setBusy(boolean busy) {
        joinButton.setEnabled(!busy);
        hostField.setEnabled(!busy);
        portField.setEnabled(!busy);
        nickField.setEnabled(!busy);
    }
}
